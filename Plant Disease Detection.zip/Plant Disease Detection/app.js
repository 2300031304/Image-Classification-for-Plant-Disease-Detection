// Plant Disease Detection - Frontend JavaScript

// API Base URL - Change this to your backend URL
const API_BASE_URL = 'http://127.0.0.1:5000';

// DOM Elements
const uploadArea = document.getElementById('uploadArea');
const fileInput = document.getElementById('fileInput');
const uploadSection = document.getElementById('uploadSection');
const previewSection = document.getElementById('previewSection');
const resultSection = document.getElementById('resultSection');
const loading = document.getElementById('loading');
const imagePreview = document.getElementById('imagePreview');
const resultImage = document.getElementById('resultImage');
const diseaseValue = document.getElementById('diseaseValue');
const confidenceValue = document.getElementById('confidenceValue');
const descriptionText = document.getElementById('descriptionText');
const recommendationText = document.getElementById('recommendationText');
const treatmentText = document.getElementById('treatmentText');

// Detection history storage (for frontend-only demo)
let detectionHistory = JSON.parse(localStorage.getItem('detectionHistory')) || [];
let currentFile = null;

// Drag and drop functionality
if (uploadArea) {
    uploadArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadArea.classList.add('dragover');
    });

    uploadArea.addEventListener('dragleave', () => {
        uploadArea.classList.remove('dragover');
    });

    uploadArea.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadArea.classList.remove('dragover');
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            handleFileSelect(files[0]);
        }
    });
}

// File input change handler
if (fileInput) {
    fileInput.addEventListener('change', (e) => {
        if (e.target.files.length > 0) {
            handleFileSelect(e.target.files[0]);
        }
    });
}

// Handle file selection
function handleFileSelect(file) {
    if (!file.type.startsWith('image/')) {
        alert('Please select an image file');
        return;
    }

    // Check file size (max 16MB)
    if (file.size > 16 * 1024 * 1024) {
        alert('File size must be less than 16MB');
        return;
    }

    currentFile = file;
    
    const reader = new FileReader();
    reader.onload = (e) => {
        imagePreview.src = e.target.result;
        uploadSection.style.display = 'none';
        previewSection.style.display = 'block';
        resultSection.style.display = 'none';
    };
    reader.readAsDataURL(file);
}

// Classify image - Connect to Flask backend
async function classifyImage() {
    if (!currentFile) {
        alert('Please select an image first');
        return;
    }

    previewSection.style.display = 'none';
    loading.style.display = 'block';
    resultSection.style.display = 'none';

    const formData = new FormData();
    formData.append('image', currentFile);

    try {
        const response = await fetch(API_BASE_URL + '/detect', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        loading.style.display = 'none';
        
        if (data.success) {
            const detection = data.detection;
            
            // Update result image
            resultImage.src = detection.image_url;
            
            // Update result details
            diseaseValue.textContent = detection.disease;
            confidenceValue.textContent = detection.confidence + '%';
            descriptionText.textContent = detection.description;
            recommendationText.textContent = detection.recommendation;
            treatmentText.textContent = detection.treatment || 'N/A';
            
            // Style based on disease status
            if (detection.disease === 'Healthy') {
                diseaseValue.style.color = '#27ae60';
            } else {
                diseaseValue.style.color = '#e74c3c';
            }
            
            resultSection.style.display = 'block';
            
            // Save to local storage for history
            saveDetection(detection);
            
            // Update dashboard stats
            updateDashboardStats();
        } else {
            alert('Error: ' + data.message);
            previewSection.style.display = 'block';
        }
    } catch (error) {
        console.error('Error:', error);
        loading.style.display = 'none';
        previewSection.style.display = 'block';
        
        // Fallback: Simulate detection for demo purposes
        simulateDetection();
    }
}

// Simulate detection for demo (when backend is not available)
function simulateDetection() {
    const diseases = [
        { disease: 'Healthy', confidence: 98.5, description: 'Your plant appears to be healthy with no visible signs of disease.', recommendation: 'Continue with regular watering and maintenance.', treatment: 'No treatment needed.' },
        { disease: 'Bacterial Spot', confidence: 94.2, description: 'Bacterial spot causes dark, water-soaked lesions on leaves.', recommendation: 'Remove infected leaves, improve air circulation.', treatment: 'Consider using copper-based bactericides.' },
        { disease: 'Early Blight', confidence: 92.8, description: 'Early blight appears as dark brown spots with concentric rings.', recommendation: 'Remove infected plant parts, apply fungicide.', treatment: 'Apply chlorothalonil or copper fungicide.' },
        { disease: 'Late Blight', confidence: 91.5, description: 'Late blight is a serious disease that causes water-soaked lesions.', recommendation: 'Remove and destroy infected plants immediately.', treatment: 'Use mancozeb or copper-based fungicides.' },
        { disease: 'Powdery Mildew', confidence: 96.4, description: 'Powdery mildew appears as white powdery coating on leaves.', recommendation: 'Improve air circulation and remove infected parts.', treatment: 'Apply fungicide or baking soda solution.' },
        { disease: 'Spider Mites', confidence: 89.3, description: 'Spider mites cause tiny yellow or white stippling on leaves.', recommendation: 'Spray plants with water to dislodge mites.', treatment: 'Use insecticidal soap or neem oil.' }
    ];
    
    // Weighted random selection
    const weights = [40, 10, 10, 8, 12, 10];
    const totalWeight = weights.reduce((a, b) => a + b, 0);
    let random = Math.random() * totalWeight;
    let selectedIndex = 0;
    
    for (let i = 0; i < weights.length; i++) {
        random -= weights[i];
        if (random <= 0) {
            selectedIndex = i;
            break;
        }
    }
    
    const result = diseases[selectedIndex];
    const timestamp = new Date().toISOString();
    const filename = `demo_${Date.now()}.jpg`;
    
    // Create a data URL for the image
    const dataUrl = imagePreview.src;
    
    // Save to local storage
    const detection = {
        id: Date.now(),
        filename: filename,
        image_url: dataUrl,
        disease: result.disease,
        confidence: result.confidence,
        description: result.description,
        recommendation: result.recommendation,
        treatment: result.treatment,
        detected_at: timestamp
    };
    
    saveDetection(detection);
    
    // Update UI
    resultImage.src = dataUrl;
    diseaseValue.textContent = detection.disease;
    confidenceValue.textContent = detection.confidence + '%';
    descriptionText.textContent = detection.description;
    recommendationText.textContent = detection.recommendation;
    treatmentText.textContent = detection.treatment;
    
    if (detection.disease === 'Healthy') {
        diseaseValue.style.color = '#27ae60';
    } else {
        diseaseValue.style.color = '#e74c3c';
    }
    
    resultSection.style.display = 'block';
    updateDashboardStats();
}

// Save detection to local storage
function saveDetection(detection) {
    detectionHistory.unshift(detection);
    localStorage.setItem('detectionHistory', JSON.stringify(detectionHistory));
}

// Reset upload
function resetUpload() {
    currentFile = null;
    if (fileInput) {
        fileInput.value = '';
    }
    if (imagePreview) {
        imagePreview.src = '';
    }
    if (resultImage) {
        resultImage.src = '';
    }
    if (uploadSection) {
        uploadSection.style.display = 'flex';
    }
    if (previewSection) {
        previewSection.style.display = 'none';
    }
    if (resultSection) {
        resultSection.style.display = 'none';
    }
    if (loading) {
        loading.style.display = 'none';
    }
}

// Show page (SPA navigation)
function showPage(pageName) {
    // Hide all pages
    document.getElementById('home-page').style.display = 'none';
    document.getElementById('dashboard-page').style.display = 'none';
    document.getElementById('history-page').style.display = 'none';
    
    // Remove active class from nav links
    document.querySelectorAll('.sidebar nav a').forEach(link => {
        link.classList.remove('active');
    });
    
    // Show selected page
    if (pageName === 'home') {
        document.getElementById('home-page').style.display = 'block';
        document.querySelector('.sidebar nav a:nth-child(1)').classList.add('active');
    } else if (pageName === 'dashboard') {
        document.getElementById('dashboard-page').style.display = 'block';
        document.querySelector('.sidebar nav a:nth-child(2)').classList.add('active');
        updateDashboardStats();
        loadRecentDetections();
    } else if (pageName === 'history') {
        document.getElementById('history-page').style.display = 'block';
        document.querySelector('.sidebar nav a:nth-child(3)').classList.add('active');
        loadHistory();
    }
}

// Update dashboard statistics
function updateDashboardStats() {
    const total = detectionHistory.length;
    const healthy = detectionHistory.filter(d => d.disease === 'Healthy').length;
    const diseased = total - healthy;
    const healthRate = total > 0 ? Math.round((healthy / total) * 100) : 0;
    
    document.getElementById('totalDetections').textContent = total;
    document.getElementById('healthyCount').textContent = healthy;
    document.getElementById('diseaseCount').textContent = diseased;
    document.getElementById('healthRate').textContent = healthRate + '%';
}

// Load recent detections
function loadRecentDetections() {
    const tbody = document.getElementById('recentTableBody');
    const recent = detectionHistory.slice(0, 5);
    
    if (recent.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="4" class="no-data">
                    <i class="fas fa-inbox"></i>
                    <p>No recent detections</p>
                </td>
            </tr>
        `;
        return;
    }
    
    tbody.innerHTML = recent.map(detection => `
        <tr>
            <td><img src="${detection.image_url}" alt="Plant" class="table-image"></td>
            <td><span class="disease-badge ${detection.disease === 'Healthy' ? 'healthy' : 'diseased'}">${detection.disease}</span></td>
            <td>${detection.confidence}%</td>
            <td class="date-cell">
                <i class="fas fa-clock"></i>
                ${new Date(detection.detected_at).toLocaleDateString()}
            </td>
        </tr>
    `).join('');
}

// Load history
function loadHistory() {
    const tbody = document.getElementById('historyTableBody');
    document.getElementById('totalRecords').textContent = detectionHistory.length;
    
    if (detectionHistory.length === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="5" class="no-data">
                    <i class="fas fa-inbox"></i>
                    <p>No detection history</p>
                </td>
            </tr>
        `;
        return;
    }
    
    tbody.innerHTML = detectionHistory.map(detection => `
        <tr>
            <td><img src="${detection.image_url}" alt="Plant" class="history-image"></td>
            <td><span class="disease-badge ${detection.disease === 'Healthy' ? 'healthy' : 'diseased'}">${detection.disease}</span></td>
            <td>${detection.confidence}%</td>
            <td class="description-cell">${detection.description.substring(0, 50)}...</td>
            <td class="date-cell">
                <i class="fas fa-calendar"></i>
                ${new Date(detection.detected_at).toLocaleDateString()}
                <br><small>${new Date(detection.detected_at).toLocaleTimeString()}</small>
            </td>
        </tr>
    `).join('');
}

// Initialize - hide all sections except upload
document.addEventListener('DOMContentLoaded', function() {
    if (uploadSection && previewSection && resultSection && loading) {
        uploadSection.style.display = 'flex';
        previewSection.style.display = 'none';
        resultSection.style.display = 'none';
        loading.style.display = 'none';
    }
    
    // Initialize dashboard stats
    updateDashboardStats();
});
